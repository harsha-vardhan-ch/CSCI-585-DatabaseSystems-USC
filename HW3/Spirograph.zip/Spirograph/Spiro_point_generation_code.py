import math

R=8
r=1
a=4
t=0.01
with open("spiro_python_output.txt", 'w') as f:
	while t<16*math.pi:
		x= ((R+r)*math.cos((r/R)*t) - a*math.cos((1+r/R)*t))*0.0001 - 118.285432
		y= ((R+r)*math.sin((r/R)*t) - a*math.sin((1+r/R)*t))*0.0001 + 34.020584
		result=str(x)+','+str(y)+'\n'
		f.write(result)
		result=''
		t=t+0.01
f.close()